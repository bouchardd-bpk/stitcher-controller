const { createApp } = Vue;
const API_BASE = globalThis.location.port === "5173" ? "http://localhost:8812" : "";

createApp({
  data() {
    return {
      loading: false,
      saving: false,
      testingUrl: false,
      activePanel: "config",
      statusRunning: false,
      statusOutput: "",
      saveMessage: "",
      testUrlValue: "http://localhost:1080/bpk-tv/jumping/dvr30sdefault/index.mpd",
      testResult: null,
      config: {
        default_settings: {
          param_dvrwindow: "dvr_window_length",
          param_sessionid: "sessionid",
          init_dvrwindow: "8h",
          incr_dvrwindow: "30s",
          session_expiration: "15s",
          manifest_expiration: "1s",
        },
        services: [],
        upstream_origin_endpoints: [],
      },
      endpointText: "",
      backups: [],
      pollTimer: null,
    };
  },
  computed: {
    statusBadgeClass() {
      return this.statusRunning ? "badge-running" : "badge-stopped";
    },
    testStatusClass() {
      if (!this.testResult) {
        return "text-bg-secondary";
      }
      return this.testResult.ok ? "text-bg-success" : "text-bg-danger";
    },
  },
  methods: {
    stripOuterQuotes(value) {
      const current = String(value ?? "").trim();
      if (current.length >= 2 && current.startsWith('"') && current.endsWith('"')) {
        return current.slice(1, -1);
      }
      return current;
    },
    ensureQuoted(value) {
      return `"${this.stripOuterQuotes(value)}"`;
    },
    withQuotedDefaultSettings(settings) {
      return {
        ...settings,
        param_dvrwindow: this.ensureQuoted(settings.param_dvrwindow),
        param_sessionid: this.ensureQuoted(settings.param_sessionid),
      };
    },
    async api(path, options = {}) {
      const response = await fetch(`${API_BASE}${path}`, {
        headers: { "Content-Type": "application/json" },
        ...options,
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(body.detail ? JSON.stringify(body.detail, null, 2) : `HTTP Error ${response.status}`);
      }
      return body;
    },
    newService() {
      return {
        name: "new_service",
        settings: {
          init_dvrwindow: "10min",
          incr_dvrwindow: "15s",
          session_expiration: "",
          manifest_expiration: "",
        },
      };
    },
    addService() {
      this.config.services.push(this.newService());
    },
    removeService(index) {
      this.config.services.splice(index, 1);
    },
    async loadStatus() {
      try {
        const data = await this.api("/api/status");
        this.statusRunning = data.running;
        this.statusOutput = `${data.status.stdout || ""}${data.status.stderr || ""}`.trim();
      } catch (error) {
        this.statusOutput = String(error.message || error);
      }
    },
    async runAction(action) {
      this.loading = true;
      this.saveMessage = "";
      try {
        const data = await this.api(`/api/control/${action}`, { method: "POST" });
        this.statusRunning = data.running;
        this.statusOutput = `${data.result.stdout || ""}${data.result.stderr || ""}`.trim();
      } catch (error) {
        this.statusOutput = String(error.message || error);
      } finally {
        this.loading = false;
      }
    },
    normalizeConfig(data) {
      this.config.default_settings = {
        param_dvrwindow: this.stripOuterQuotes(data.default_settings.param_dvrwindow || '"dvr_window_length"'),
        param_sessionid: this.stripOuterQuotes(data.default_settings.param_sessionid || '"sessionid"'),
        init_dvrwindow: data.default_settings.init_dvrwindow || "8h",
        incr_dvrwindow: data.default_settings.incr_dvrwindow || "30s",
        session_expiration: data.default_settings.session_expiration || "15s",
        manifest_expiration: data.default_settings.manifest_expiration || "1s",
      };
      this.config.services = (data.services || []).map((service) => ({
        name: service.name,
        settings: {
          init_dvrwindow: service.settings.init_dvrwindow || "",
          incr_dvrwindow: service.settings.incr_dvrwindow || "",
          session_expiration: service.settings.session_expiration || "",
          manifest_expiration: service.settings.manifest_expiration || "",
        },
      }));
      this.config.upstream_origin_endpoints = data.upstream_origin_endpoints || [];
      this.endpointText = this.config.upstream_origin_endpoints.join("\n");
    },
    async loadConfig() {
      const data = await this.api("/api/config");
      this.normalizeConfig(data);
    },
    async loadBackups() {
      const data = await this.api("/api/backups");
      this.backups = data.backups || [];
    },
    async saveConfig() {
      this.saving = true;
      this.saveMessage = "";
      this.config.upstream_origin_endpoints = this.endpointText
        .split("\n")
        .map((line) => line.trim())
        .filter(Boolean);
      try {
        const payload = {
          default_settings: this.withQuotedDefaultSettings(this.config.default_settings),
          services: this.config.services,
          upstream_origin_endpoints: this.config.upstream_origin_endpoints,
        };
        const data = await this.api("/api/config", {
          method: "PUT",
          body: JSON.stringify(payload),
        });
        this.saveMessage = `Saved. Backup: ${data.backup}`;
        await this.loadBackups();
      } catch (error) {
        this.saveMessage = `Error: ${String(error.message || error)}`;
      } finally {
        this.saving = false;
      }
    },
    async restoreBackup(name) {
      if (!confirm(`Restore backup ${name}?`)) {
        return;
      }
      try {
        await this.api(`/api/backups/${name}/restore`, { method: "POST" });
        this.saveMessage = `Restored: ${name}`;
        await this.loadConfig();
        await this.loadBackups();
      } catch (error) {
        this.saveMessage = `Restore error: ${String(error.message || error)}`;
      }
    },
    async testUrl() {
      this.testingUrl = true;
      this.testResult = null;
      try {
        this.testResult = await this.api("/api/test-url", {
          method: "POST",
          body: JSON.stringify({
            url: this.testUrlValue,
            timeout_seconds: 20,
          }),
        });
      } catch (error) {
        this.testResult = {
          ok: false,
          status: "ERROR",
          error: String(error.message || error),
          elapsed_ms: 0,
          headers: {},
          body_preview: "",
        };
      } finally {
        this.testingUrl = false;
      }
    },
    openPlayer() {
      const targetUrl = (this.testResult?.final_url || this.testUrlValue || "").trim();
      if (!targetUrl) {
        return;
      }
      try {
        const payload = JSON.stringify({
          src: targetUrl,
          autoplay: true,
          ts: Date.now(),
        });
        globalThis.localStorage.setItem("stitcher_player_request", payload);
      } catch (error) {
        globalThis.console.warn("Unable to persist player request", error);
      }
      globalThis.open(`/player.html?src=${encodeURIComponent(targetUrl)}&autoplay=1`, "_blank", "noopener,noreferrer");
    },
  },
  async mounted() {
    await this.loadStatus();
    await this.loadConfig();
    await this.loadBackups();
    this.pollTimer = globalThis.setInterval(() => {
      if (!document.hidden && !this.loading) {
        this.loadStatus();
      }
    }, 5000);
  },
  unmounted() {
    if (this.pollTimer) {
      globalThis.clearInterval(this.pollTimer);
    }
  },
  template: `
    <div class="app-shell">
      <nav class="hero-navbar">
        <div class="navbar-inner">
          <span class="nav-brand">
            <i class="bi bi-broadcast-pin me-2"></i>Stitcher Controller
          </span>
          <div class="nav-actions">
            <span class="status-badge" :class="statusBadgeClass">
              <span class="status-dot"></span>
              {{ statusRunning ? 'RUNNING' : 'STOPPED' }}
            </span>
            <button
              v-if="!statusRunning"
              class="btn btn-success btn-sm"
              :disabled="loading"
              @click="runAction('start')"
            >
              <i class="bi bi-play-fill me-1"></i>Start
            </button>
            <button
              v-else
              class="btn btn-danger btn-sm"
              :disabled="loading"
              @click="runAction('stop')"
            >
              <i class="bi bi-stop-fill me-1"></i>Stop
            </button>
            <button
              class="btn btn-warning btn-sm"
              :disabled="loading || !statusRunning"
              @click="runAction('reload')"
            >
              <i class="bi bi-arrow-clockwise me-1"></i>Reload
            </button>
          </div>
        </div>
      </nav>

      <div class="app-body">
        <aside class="sidebar">
          <button
            class="sidebar-btn"
            :class="{ active: activePanel === 'config' }"
            @click="activePanel = 'config'"
            title="Configuration"
          >
            <i class="bi bi-gear-fill"></i>
          </button>
          <button
            class="sidebar-btn"
            :class="{ active: activePanel === 'tester' }"
            @click="activePanel = 'tester'"
            title="URL Tester"
          >
            <i class="bi bi-globe2"></i>
          </button>
        </aside>

        <main class="main-content">
          <div v-if="statusOutput" class="output-bar">
            <div class="output-bar-label">
              <i class="bi bi-terminal me-1"></i>Last output
            </div>
            <pre class="output-bar-pre">{{ statusOutput }}</pre>
          </div>

          <div v-if="activePanel === 'config'" class="panel-area">
            <div class="row g-3 mb-1">
              <div class="col-12 col-xl-6">
                <div class="card panel-card h-100">
                  <div class="card-body">
                    <h6 class="card-title mb-3">Default Settings</h6>
                    <div class="row g-2">
                      <div class="col-12 col-md-6">
                        <label class="form-label">param_dvrwindow</label>
                        <input class="form-control form-control-sm" v-model="config.default_settings.param_dvrwindow" />
                      </div>
                      <div class="col-12 col-md-6">
                        <label class="form-label">param_sessionid</label>
                        <input class="form-control form-control-sm" v-model="config.default_settings.param_sessionid" />
                      </div>
                      <div class="col-12 col-md-6">
                        <label class="form-label">init_dvrwindow</label>
                        <input class="form-control form-control-sm" v-model="config.default_settings.init_dvrwindow" />
                      </div>
                      <div class="col-12 col-md-6">
                        <label class="form-label">incr_dvrwindow</label>
                        <input class="form-control form-control-sm" v-model="config.default_settings.incr_dvrwindow" />
                      </div>
                      <div class="col-12 col-md-6">
                        <label class="form-label">session_expiration</label>
                        <input class="form-control form-control-sm" v-model="config.default_settings.session_expiration" />
                      </div>
                      <div class="col-12 col-md-6">
                        <label class="form-label">manifest_expiration</label>
                        <input class="form-control form-control-sm" v-model="config.default_settings.manifest_expiration" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-12 col-xl-6">
                <div class="card panel-card h-100">
                  <div class="card-body d-flex flex-column">
                    <h6 class="card-title mb-3">Upstream Origin</h6>
                    <label class="form-label">Endpoints (one per line)</label>
                    <textarea class="form-control flex-grow-1" rows="7" v-model="endpointText"></textarea>
                  </div>
                </div>
              </div>
            </div>

            <div class="card panel-card">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <h6 class="card-title mb-0">Services</h6>
                  <button class="btn btn-primary btn-sm" @click="addService">
                    <i class="bi bi-plus-lg me-1"></i>Add service
                  </button>
                </div>
                <div class="row g-3">
                  <div
                    v-for="(service, index) in config.services"
                    :key="index"
                    class="col-12 col-md-6 col-xl-4"
                  >
                    <div class="card service-grid-card h-100 border-0">
                      <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                          <span class="fw-semibold small">Service {{ index + 1 }}</span>
                          <button class="btn btn-outline-danger btn-sm" @click="removeService(index)">
                            <i class="bi bi-trash3"></i>
                          </button>
                        </div>
                        <div class="mb-2">
                          <label class="form-label mb-1">Name</label>
                          <input class="form-control form-control-sm" v-model="service.name" />
                        </div>
                        <div class="row g-2">
                          <div class="col-6">
                            <label class="form-label mb-1">init_dvrwindow</label>
                            <input class="form-control form-control-sm" v-model="service.settings.init_dvrwindow" />
                          </div>
                          <div class="col-6">
                            <label class="form-label mb-1">incr_dvrwindow</label>
                            <input class="form-control form-control-sm" v-model="service.settings.incr_dvrwindow" />
                          </div>
                          <div class="col-6">
                            <label class="form-label mb-1">session_expiration</label>
                            <input class="form-control form-control-sm" v-model="service.settings.session_expiration" />
                          </div>
                          <div class="col-6">
                            <label class="form-label mb-1">manifest_expiration</label>
                            <input class="form-control form-control-sm" v-model="service.settings.manifest_expiration" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div v-if="config.services.length === 0" class="col-12 text-muted small">No services configured.</div>
                </div>
              </div>
            </div>

            <div class="card panel-card">
              <div class="card-body">
                <h6 class="card-title mb-3">Save & Backups</h6>
                <div class="d-flex flex-wrap gap-2 mb-3">
                  <button class="btn btn-primary btn-sm" :disabled="saving" @click="saveConfig">
                    <i class="bi bi-floppy me-1"></i>{{ saving ? 'Saving...' : 'Save Config' }}
                  </button>
                  <button class="btn btn-outline-secondary btn-sm" :disabled="saving" @click="loadConfig">
                    <i class="bi bi-arrow-counterclockwise me-1"></i>Reload from file
                  </button>
                </div>
                <div v-if="saveMessage" class="alert alert-info py-2 small mb-3">{{ saveMessage }}</div>
                <div class="d-flex flex-wrap gap-2 align-items-center">
                  <span class="text-muted small">Backups:</span>
                  <button v-for="backup in backups" :key="backup" class="btn btn-outline-secondary btn-sm" @click="restoreBackup(backup)">
                    {{ backup }}
                  </button>
                  <span v-if="backups.length === 0" class="text-muted small">No backups yet.</span>
                </div>
              </div>
            </div>
          </div>

          <div v-else class="panel-area">
            <div class="card panel-card">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                  <h6 class="card-title mb-0">URL Tester</h6>
                  <span v-if="testResult" class="badge" :class="testStatusClass">{{ testResult.status }}</span>
                </div>
                <div class="input-group mb-3">
                  <input class="form-control" v-model="testUrlValue" placeholder="Enter URL to test" />
                  <button class="btn btn-primary" :disabled="testingUrl || !testUrlValue" @click="testUrl">
                    <i class="bi bi-send me-1"></i>{{ testingUrl ? 'Testing...' : 'Test' }}
                  </button>
                  <button class="btn btn-outline-primary" :disabled="!testUrlValue" @click="openPlayer">
                    <i class="bi bi-play-circle me-1"></i>Player
                  </button>
                </div>
                <div v-if="testResult" class="small">
                  <p class="mb-1"><strong>Elapsed:</strong> {{ testResult.elapsed_ms }} ms</p>
                  <p class="mb-1" v-if="testResult.final_url"><strong>Final URL:</strong> {{ testResult.final_url }}</p>
                  <p class="mb-2 text-danger" v-if="testResult.error"><strong>Error:</strong> {{ testResult.error }}</p>
                  <details>
                    <summary class="mb-1 text-muted">Response headers</summary>
                    <pre class="response-box">{{ JSON.stringify(testResult.headers || {}, null, 2) }}</pre>
                  </details>
                  <details class="mt-2">
                    <summary class="mb-1 text-muted">Response body preview</summary>
                    <pre class="response-box">{{ testResult.body_preview || '(empty body)' }}</pre>
                  </details>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  `,
}).mount("#app");