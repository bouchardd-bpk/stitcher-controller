#!/usr/bin/env bash

set -e

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ ! -d "$ROOT_DIR/.venv" ]; then
  # Ensure python3-venv is available (Debian/Ubuntu)
  if ! python3 -m venv --help >/dev/null 2>&1; then
    echo "python3-venv not found, installing..."
    if command -v apt-get >/dev/null 2>&1; then
      sudo apt-get install -y python3-venv
    else
      echo "ERROR: python3-venv is not available. Install it manually:" >&2
      echo "  apt install python3-venv   (Debian/Ubuntu)" >&2
      echo "  dnf install python3        (RHEL/Fedora)" >&2
      exit 1
    fi
  fi
  python3 -m venv "$ROOT_DIR/.venv"
fi

source "$ROOT_DIR/.venv/bin/activate"
pip install -r "$ROOT_DIR/backend/requirements.txt"

exec uvicorn backend.app.main:app --host 0.0.0.0 --port 8088 --reload --app-dir "$ROOT_DIR"
