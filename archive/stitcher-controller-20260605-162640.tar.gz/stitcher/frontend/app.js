const { createApp } = Vue;
const API_BASE = globalThis.location.port === "5173" ? "http://localhost:8088" : "";

createApp({
  data() {
    return {
      loading: false,
      saving: false,
      testingUrl: false,
      activeTab: "control",
      statusRunning: false,
      statusOutput: "",
      saveMessage: "",
      testUrlValue: "http://localhost:1080/bpk-tv/jumping/dvr30sdefault/index.mpd",
      testResult: null,
      config: {
        default_settings: {
          param_dvrwindow: "dvr_window_length",
          param_sessionid: "sessionid",
          init_dvrwindow: "8h",
          incr_dvrwindow: "30s",
          session_expiration: "15s",
          manifest_expiration: "1s",
        },
        services: [],
        upstream_origin_endpoints: [],
      },
      endpointText: "",
      backups: [],
    };
  },
  computed: {
    statusBadgeClass() {
      return this.statusRunning ? "bg-success-subtle text-success" : "bg-danger-subtle text-danger";
    },
    testStatusClass() {
      if (!this.testResult) {
        return "text-bg-secondary";
      }
      return this.testResult.ok ? "text-bg-success" : "text-bg-danger";
    },
  },
  methods: {
    stripOuterQuotes(value) {
      const v = String(value ?? "").trim();
      if (v.length >= 2 && v.startsWith('"') && v.endsWith('"')) {
        return v.slice(1, -1);
      }
      return v;
    },
    ensureQuoted(value) {
      const v = this.stripOuterQuotes(value);
      return `"${v}"`;
    },
    withQuotedDefaultSettings(settings) {
      return {
        ...settings,
        param_dvrwindow: this.ensureQuoted(settings.param_dvrwindow),
        param_sessionid: this.ensureQuoted(settings.param_sessionid),
      };
    },
    async api(path, options = {}) {
      const res = await fetch(`${API_BASE}${path}`, {
        headers: { "Content-Type": "application/json" },
        ...options,
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(body.detail ? JSON.stringify(body.detail, null, 2) : `HTTP Error ${res.status}`);
      }
      return body;
    },
    newService() {
      return {
        name: "new_service",
        settings: {
          init_dvrwindow: "10min",
          incr_dvrwindow: "15s",
        },
      };
    },
    addService() {
      this.config.services.push(this.newService());
    },
    removeService(index) {
      this.config.services.splice(index, 1);
    },
    async loadStatus() {
      const data = await this.api("/api/status");
      this.statusRunning = data.running;
      this.statusOutput = `${data.status.stdout || ""}${data.status.stderr || ""}`.trim();
    },
    async runAction(action) {
      this.loading = true;
      this.saveMessage = "";
      try {
        const data = await this.api(`/api/control/${action}`, { method: "POST" });
        this.statusRunning = data.running;
        this.statusOutput = `${data.result.stdout || ""}${data.result.stderr || ""}`.trim();
      } catch (err) {
        this.statusOutput = String(err.message || err);
      } finally {
        this.loading = false;
      }
    },
    normalizeConfig(data) {
      this.config.default_settings = {
        param_dvrwindow: this.stripOuterQuotes(data.default_settings.param_dvrwindow || '"dvr_window_length"'),
        param_sessionid: this.stripOuterQuotes(data.default_settings.param_sessionid || '"sessionid"'),
        init_dvrwindow: data.default_settings.init_dvrwindow || "8h",
        incr_dvrwindow: data.default_settings.incr_dvrwindow || "30s",
        session_expiration: data.default_settings.session_expiration || "15s",
        manifest_expiration: data.default_settings.manifest_expiration || "1s",
      };
      this.config.services = (data.services || []).map((service) => ({
        name: service.name,
        settings: {
          init_dvrwindow: service.settings.init_dvrwindow || "",
          incr_dvrwindow: service.settings.incr_dvrwindow || "",
          session_expiration: service.settings.session_expiration || "",
          manifest_expiration: service.settings.manifest_expiration || "",
        },
      }));
      this.config.upstream_origin_endpoints = data.upstream_origin_endpoints || [];
      this.endpointText = this.config.upstream_origin_endpoints.join("\n");
    },
    async loadConfig() {
      const data = await this.api("/api/config");
      this.normalizeConfig(data);
    },
    async loadBackups() {
      const data = await this.api("/api/backups");
      this.backups = data.backups || [];
    },
    async saveConfig() {
      this.saving = true;
      this.saveMessage = "";
      this.config.upstream_origin_endpoints = this.endpointText
        .split("\n")
        .map((line) => line.trim())
        .filter(Boolean);
      try {
        const payload = {
          default_settings: this.withQuotedDefaultSettings(this.config.default_settings),
          services: this.config.services,
          upstream_origin_endpoints: this.config.upstream_origin_endpoints,
        };
        const data = await this.api("/api/config", {
          method: "PUT",
          body: JSON.stringify(payload),
        });
        this.saveMessage = `Configuration saved. Backup created: ${data.backup}`;
        await this.loadBackups();
      } catch (err) {
        this.saveMessage = `Error: ${String(err.message || err)}`;
      } finally {
        this.saving = false;
      }
    },
    async restoreBackup(name) {
      if (!confirm(`Restore backup ${name}?`)) {
        return;
      }
      try {
        await this.api(`/api/backups/${name}/restore`, { method: "POST" });
        this.saveMessage = `Backup restored: ${name}`;
        await this.loadConfig();
        await this.loadBackups();
      } catch (err) {
        this.saveMessage = `Restore error: ${String(err.message || err)}`;
      }
    },
    async testUrl() {
      this.testingUrl = true;
      this.testResult = null;
      try {
        const data = await this.api("/api/test-url", {
          method: "POST",
          body: JSON.stringify({
            url: this.testUrlValue,
            timeout_seconds: 20,
          }),
        });
        this.testResult = data;
      } catch (err) {
        this.testResult = {
          ok: false,
          status: "ERROR",
          error: String(err.message || err),
          elapsed_ms: 0,
          headers: {},
          body_preview: "",
        };
      } finally {
        this.testingUrl = false;
      }
    },
    openPlayer() {
      const targetUrl = (this.testResult?.final_url || this.testUrlValue || "").trim();
      if (!targetUrl) {
        return;
      }
      try {
        const payload = JSON.stringify({
          src: targetUrl,
          autoplay: true,
          ts: Date.now(),
        });
        globalThis.localStorage.setItem("stitcher_player_request", payload);
      } catch (err) {
        globalThis.console.warn("Unable to persist player request", err);
      }
      const playerUrl = `/player.html?src=${encodeURIComponent(targetUrl)}&autoplay=1`;
      globalThis.open(playerUrl, "_blank", "noopener,noreferrer");
    },
  },
  async mounted() {
    await this.loadStatus();
    await this.loadConfig();
    await this.loadBackups();
  },
  template: `
    <div class="app-shell pb-4">
      <nav class="navbar navbar-expand-lg navbar-dark hero-navbar shadow-sm">
        <div class="container-fluid px-4">
          <span class="navbar-brand fw-bold">Stitcher Controller</span>
          <span class="badge fs-6" :class="statusBadgeClass">{{ statusRunning ? 'RUNNING' : 'STOPPED' }}</span>
        </div>
      </nav>

      <main class="container py-4">
        <section class="tab-surface p-3 p-md-4">
          <ul class="nav nav-tabs mb-4">
            <li class="nav-item">
              <button
                class="nav-link"
                :class="{ active: activeTab === 'control' }"
                @click="activeTab = 'control'"
                type="button"
              >Stitcher Control</button>
            </li>
            <li class="nav-item">
              <button
                class="nav-link"
                :class="{ active: activeTab === 'config' }"
                @click="activeTab = 'config'"
                type="button"
              >Configuration</button>
            </li>
            <li class="nav-item">
              <button
                class="nav-link"
                :class="{ active: activeTab === 'tester' }"
                @click="activeTab = 'tester'"
                type="button"
              >URL Tester</button>
            </li>
          </ul>

          <div class="tab-content-scroll">

          <div v-if="activeTab === 'tester'" class="row g-4">
          <div class="col-12">
            <div class="card border-0 shadow-sm panel-card">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
                  <h5 class="card-title mb-0">URL Tester</h5>
                  <span v-if="testResult" class="badge" :class="testStatusClass">Status: {{ testResult.status }}</span>
                </div>
                <div class="input-group mb-3">
                  <input class="form-control" v-model="testUrlValue" placeholder="Enter URL to test" />
                  <button class="btn btn-primary" :disabled="testingUrl || !testUrlValue" @click="testUrl">
                    {{ testingUrl ? 'Testing...' : 'Test URL' }}
                  </button>
                  <button class="btn btn-outline-primary" :disabled="!testUrlValue" @click="openPlayer">
                    Open Player
                  </button>
                </div>
                <div v-if="testResult" class="small">
                  <p class="mb-1"><strong>Elapsed:</strong> {{ testResult.elapsed_ms }} ms</p>
                  <p class="mb-1" v-if="testResult.final_url"><strong>Final URL:</strong> {{ testResult.final_url }}</p>
                  <p class="mb-2 text-danger" v-if="testResult.error"><strong>Error:</strong> {{ testResult.error }}</p>
                  <details>
                    <summary class="mb-1">Response headers</summary>
                    <pre class="response-box">{{ JSON.stringify(testResult.headers || {}, null, 2) }}</pre>
                  </details>
                  <details class="mt-2">
                    <summary class="mb-1">Response body preview</summary>
                    <pre class="response-box">{{ testResult.body_preview || '(empty body)' }}</pre>
                  </details>
                </div>
              </div>
            </div>
          </div>
        </div>

          <div v-else-if="activeTab === 'control'" class="row g-4">
          <div class="col-12">
            <div class="card border-0 shadow-sm panel-card">
              <div class="card-body">
                <h5 class="card-title mb-3">Control Panel</h5>
                <div class="d-flex flex-wrap gap-2 mb-3">
                  <button class="btn btn-success" :disabled="loading" @click="runAction('start')">Start</button>
                  <button class="btn btn-danger" :disabled="loading" @click="runAction('stop')">Stop</button>
                  <button class="btn btn-warning" :disabled="loading || !statusRunning" @click="runAction('reload')">Reload Config</button>
                  <button class="btn btn-secondary" :disabled="loading" @click="runAction('restart')">Restart</button>
                  <button class="btn btn-outline-secondary" :disabled="loading" @click="loadStatus">Refresh Status</button>
                </div>
                <label class="form-label text-muted">Command output</label>
                <pre class="terminal-log mb-0">{{ statusOutput || 'No output yet.' }}</pre>
              </div>
            </div>
          </div>
        </div>

          <div v-else class="row g-4">

          <div class="col-12 col-xl-6">
            <div class="card border-0 shadow-sm panel-card h-100">
              <div class="card-body">
                <h5 class="card-title mb-3">Default Service Settings</h5>
                <div class="row g-3">
                  <div class="col-12 col-md-6">
                    <label class="form-label">param_dvrwindow</label>
                    <input class="form-control" v-model="config.default_settings.param_dvrwindow" />
                  </div>
                  <div class="col-12 col-md-6">
                    <label class="form-label">param_sessionid</label>
                    <input class="form-control" v-model="config.default_settings.param_sessionid" />
                  </div>
                  <div class="col-12 col-md-6">
                    <label class="form-label">init_dvrwindow</label>
                    <input class="form-control" v-model="config.default_settings.init_dvrwindow" />
                  </div>
                  <div class="col-12 col-md-6">
                    <label class="form-label">incr_dvrwindow</label>
                    <input class="form-control" v-model="config.default_settings.incr_dvrwindow" />
                  </div>
                  <div class="col-12 col-md-6">
                    <label class="form-label">session_expiration</label>
                    <input class="form-control" v-model="config.default_settings.session_expiration" />
                  </div>
                  <div class="col-12 col-md-6">
                    <label class="form-label">manifest_expiration</label>
                    <input class="form-control" v-model="config.default_settings.manifest_expiration" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-12 col-xl-6">
            <div class="card border-0 shadow-sm panel-card h-100">
              <div class="card-body d-flex flex-column">
                <h5 class="card-title mb-3">Upstream Origin</h5>
                <label class="form-label">Endpoints (one URL per line)</label>
                <textarea class="form-control flex-grow-1" rows="7" v-model="endpointText"></textarea>
              </div>
            </div>
          </div>

          <div class="col-12">
            <div class="card border-0 shadow-sm panel-card">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
                  <h5 class="card-title mb-0">Services</h5>
                  <button class="btn btn-primary btn-sm" @click="addService">Add Service</button>
                </div>
                <div class="row g-3 mt-1">
                  <div
                    v-for="(service, index) in config.services"
                    :key="index"
                    class="col-12 col-md-6 col-xl-4"
                  >
                    <div class="card service-grid-card h-100 border-0 shadow-sm">
                      <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
                          <h6 class="mb-0">Service {{ index + 1 }}</h6>
                          <button class="btn btn-outline-danger btn-sm" @click="removeService(index)">Delete</button>
                        </div>

                        <div class="mb-2">
                          <label class="form-label mb-1">Service Name</label>
                          <input class="form-control form-control-sm" v-model="service.name" />
                        </div>

                        <div class="row g-2">
                          <div class="col-6">
                            <label class="form-label mb-1">init_dvrwindow</label>
                            <input class="form-control form-control-sm" v-model="service.settings.init_dvrwindow" />
                          </div>
                          <div class="col-6">
                            <label class="form-label mb-1">incr_dvrwindow</label>
                            <input class="form-control form-control-sm" v-model="service.settings.incr_dvrwindow" />
                          </div>
                          <div class="col-6">
                            <label class="form-label mb-1">session_expiration</label>
                            <input class="form-control form-control-sm" v-model="service.settings.session_expiration" />
                          </div>
                          <div class="col-6">
                            <label class="form-label mb-1">manifest_expiration</label>
                            <input class="form-control form-control-sm" v-model="service.settings.manifest_expiration" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-12">
            <div class="card border-0 shadow-sm panel-card">
              <div class="card-body">
                <h5 class="card-title mb-3">Configuration Save</h5>
                <div class="d-flex flex-wrap gap-2 mb-3">
                  <button class="btn btn-primary" :disabled="saving" @click="saveConfig">Save Config</button>
                  <button class="btn btn-outline-secondary" :disabled="saving" @click="loadConfig">Reload From File</button>
                </div>
                <div v-if="saveMessage" class="alert alert-info py-2">{{ saveMessage }}</div>
                <p class="text-muted mb-2">Available backups</p>
                <div class="d-flex flex-wrap gap-2">
                  <button v-for="b in backups" :key="b" class="btn btn-outline-secondary btn-sm" @click="restoreBackup(b)">
                    Restore {{ b }}
                  </button>
                  <span class="text-muted" v-if="backups.length === 0">No backups yet.</span>
                </div>
              </div>
            </div>
          </div>
          </div>
          </div>
        </section>
      </main>
      <footer class="app-footer text-white mt-3">
        <div class="container py-3 d-flex justify-content-between align-items-center small">
          <span>Stitcher Controller</span>
          <span>Configuration and Testing Console</span>
        </div>
      </footer>
    </div>
  `,
}).mount("#app");