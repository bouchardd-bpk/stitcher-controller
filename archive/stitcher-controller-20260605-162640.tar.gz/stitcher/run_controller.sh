#!/usr/bin/env bash

set -e

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ ! -d "$ROOT_DIR/.venv" ]; then
  python3 -m venv "$ROOT_DIR/.venv"
fi

source "$ROOT_DIR/.venv/bin/activate"
pip install -r "$ROOT_DIR/backend/requirements.txt"

exec uvicorn backend.app.main:app --host 0.0.0.0 --port 8088 --reload --app-dir "$ROOT_DIR"
