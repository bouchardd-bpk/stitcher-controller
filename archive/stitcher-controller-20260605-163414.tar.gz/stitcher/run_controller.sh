#!/usr/bin/env bash

set -e

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"

ensure_venv() {
  if python3 -m venv "$ROOT_DIR/.venv" 2>/dev/null && [ -f "$ROOT_DIR/.venv/bin/activate" ]; then
    return 0
  fi

  # venv creation failed — install python3-venv and retry
  rm -rf "$ROOT_DIR/.venv"
  echo "python3-venv not functional, installing..."
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get install -y python3-venv
  elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y python3
  else
    echo "ERROR: cannot install python3-venv automatically." >&2
    echo "  Debian/Ubuntu: sudo apt-get install -y python3-venv" >&2
    echo "  RHEL/Fedora:   sudo dnf install -y python3" >&2
    exit 1
  fi

  python3 -m venv "$ROOT_DIR/.venv"
}

if [ ! -f "$ROOT_DIR/.venv/bin/activate" ]; then
  ensure_venv
fi

source "$ROOT_DIR/.venv/bin/activate"
pip install -r "$ROOT_DIR/backend/requirements.txt"

exec uvicorn backend.app.main:app --host 0.0.0.0 --port 8088 --reload --app-dir "$ROOT_DIR"
